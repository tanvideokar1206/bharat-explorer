package com.bharatexplorer.model;

import java.sql.Date;
import java.sql.Timestamp;

public class ServiceAppointment {
    private int appointmentId;
    private int travelerId;
    private int vendorId;
    private String serviceName;
    private Date appointmentDate;
    private String status; // PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED
    private Timestamp createdAt;

    public ServiceAppointment() {}

    public ServiceAppointment(int appointmentId, int travelerId, int vendorId, String serviceName, Date appointmentDate, String status, Timestamp createdAt) {
        this.appointmentId = appointmentId;
        this.travelerId = travelerId;
        this.vendorId = vendorId;
        this.serviceName = serviceName;
        this.appointmentDate = appointmentDate;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public int getTravelerId() { return travelerId; }
    public void setTravelerId(int travelerId) { this.travelerId = travelerId; }

    public int getVendorId() { return vendorId; }
    public void setVendorId(int vendorId) { this.vendorId = vendorId; }

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }

    public Date getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(Date appointmentDate) { this.appointmentDate = appointmentDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
