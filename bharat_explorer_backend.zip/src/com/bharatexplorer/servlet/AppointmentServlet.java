package com.bharatexplorer.servlet;

import com.bharatexplorer.dao.AppointmentDao;
import com.bharatexplorer.model.ServiceAppointment;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {
    private AppointmentDao appointmentDao = new AppointmentDao();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            int travelerId = Integer.parseInt(request.getParameter("travelerId"));
            int vendorId = Integer.parseInt(request.getParameter("vendorId"));
            String serviceName = request.getParameter("serviceName");
            Date appointmentDate = Date.valueOf(request.getParameter("appointmentDate"));

            ServiceAppointment appt = new ServiceAppointment();
            appt.setTravelerId(travelerId);
            appt.setVendorId(vendorId);
            appt.setServiceName(serviceName);
            appt.setAppointmentDate(appointmentDate);
            appt.setStatus("PENDING");

            boolean success = appointmentDao.createAppointment(appt);

            if (success) {
                out.print("{\"status\": \"SUCCESS\", \"message\": \"Appointment booked successfully!\"}");
            } else {
                out.print("{\"status\": \"ERROR\", \"message\": \"Failed to book appointment.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"status\": \"ERROR\", \"message\": \"" + e.getMessage() + "\"}");
        }
    }
}
