package com.bharatexplorer.dao;

import com.bharatexplorer.model.ServiceAppointment;
import com.bharatexplorer.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDao {

    public boolean createAppointment(ServiceAppointment appt) throws SQLException {
        String sql = "INSERT INTO ServiceAppointments (traveler_id, vendor_id, service_name, appointment_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appt.getTravelerId());
            stmt.setInt(2, appt.getVendorId());
            stmt.setString(3, appt.getServiceName());
            stmt.setDate(4, appt.getAppointmentDate());
            stmt.setString(5, appt.getStatus() != null ? appt.getStatus() : "PENDING");
            return stmt.executeUpdate() > 0;
        }
    }

    public List<ServiceAppointment> getAppointmentsByTraveler(int travelerId) throws SQLException {
        List<ServiceAppointment> list = new ArrayList<>();
        String sql = "SELECT * FROM ServiceAppointments WHERE traveler_id = ? ORDER BY appointment_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, travelerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new ServiceAppointment(
                        rs.getInt("appointment_id"),
                        rs.getInt("traveler_id"),
                        rs.getInt("vendor_id"),
                        rs.getString("service_name"),
                        rs.getDate("appointment_date"),
                        rs.getString("status"),
                        rs.getTimestamp("created_at")
                    ));
                }
            }
        }
        return list;
    }
}
