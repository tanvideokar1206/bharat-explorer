-- Bharat Explorer Database Schema
CREATE DATABASE IF NOT EXISTS bharat_explorer_db;
USE bharat_explorer_db;

CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('TRAVELER', 'VENDOR', 'ADMIN') DEFAULT 'TRAVELER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ArtisanVendors (
    vendor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    store_name VARCHAR(100) NOT NULL,
    e_pehchan_id VARCHAR(50) UNIQUE,
    gi_certified BOOLEAN DEFAULT FALSE,
    business_address TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS StateAttires (
    attire_id INT AUTO_INCREMENT PRIMARY KEY,
    state_name VARCHAR(50) NOT NULL,
    garment_name VARCHAR(100) NOT NULL,
    craft_classification VARCHAR(50) NOT NULL,
    fiber_composition VARCHAR(100) NOT NULL,
    historical_background TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ServiceAppointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    traveler_id INT NOT NULL,
    vendor_id INT NOT NULL,
    service_name VARCHAR(100) NOT NULL,
    appointment_date DATE NOT NULL,
    status ENUM('PENDING', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (traveler_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (vendor_id) REFERENCES ArtisanVendors(vendor_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS PaymentTransactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL UNIQUE,
    amount_inr DECIMAL(10,2) NOT NULL,
    payment_mode ENUM('UPI', 'CREDIT_CARD', 'DEBIT_CARD', 'NET_BANKING', 'CASH') NOT NULL,
    settlement_status ENUM('SUCCESS', 'PENDING', 'FAILED', 'REFUNDED') DEFAULT 'PENDING',
    transaction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES ServiceAppointments(appointment_id) ON DELETE CASCADE
);
